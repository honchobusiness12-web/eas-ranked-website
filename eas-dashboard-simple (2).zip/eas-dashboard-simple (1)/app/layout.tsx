import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EAS Arena Dashboard",
  description: "Discord ranked bot dashboard for EAS.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
