export default function Ranks() {
  return (
    <main className="min-h-screen bg-[#05070d] text-white p-10">
      <h1 className="text-4xl font-black mb-6">📊 Rank System</h1>
      <p className="text-zinc-400">All ranks will be explained here.</p>
    </main>
  );
}