export default function Player() {
  return (
    <main className="min-h-screen bg-[#05070d] text-white p-10">
      <h1 className="text-4xl font-black mb-6">👤 Player Profile</h1>
      <p className="text-zinc-400">Player stats will go here.</p>
    </main>
  );
}