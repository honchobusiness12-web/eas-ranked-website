import { Card, PageShell } from "@/components/ui";
import { query } from "@/lib/db";
import { TABLES } from "@/lib/schema";

export default async function PlacementsPage() {
  const placements = await query(`SELECT * FROM ${TABLES.placements} ORDER BY created_at DESC LIMIT 50`).catch(() => []);
  return (
    <PageShell>
      <h1 className="mb-2 text-4xl font-black">Placements</h1>
      <p className="mb-8 text-zinc-400">Recent placement logs from your database.</p>
      <div className="space-y-3">
        {placements.map((p: any, i: number) => <Card key={p.id || i} className="p-5"><pre className="overflow-auto text-sm text-zinc-300">{JSON.stringify(p, null, 2)}</pre></Card>)}
        {placements.length === 0 && <Card className="p-6 text-zinc-400">No placements found. Update TABLES.placements in lib/schema.ts if your table has a different name.</Card>}
      </div>
    </PageShell>
  );
}
