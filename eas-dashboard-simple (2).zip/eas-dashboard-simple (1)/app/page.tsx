const players = [
  { place: "🥇", name: "MIDNYT", rank: "R10", cr: "2,840", letter: "M" },
  { place: "🥈", name: "UncleLitch", rank: "R9", cr: "2,510", letter: "U" },
  { place: "🥉", name: "Leo", rank: "R8", cr: "2,220", letter: "L" },
  { place: "4", name: "Zizo", rank: "R7", cr: "1,970", letter: "Z" },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[#05070d] text-white">
      <div className="flex min-h-screen">
        <aside className="hidden w-72 border-r border-white/10 bg-black/30 p-6 lg:block">
          <h1 className="text-2xl font-black">
            EAS <span className="text-purple-500">ARENA</span>
          </h1>

          <nav className="mt-10 space-y-2">
            {["Dashboard", "Leaderboard", "Players", "Team Rankings", "Matches", "MVPs", "CR Profiles", "Staff Tools"].map((item, i) => (
              <div
                key={item}
                className={`rounded-xl px-4 py-3 text-sm ${
                  i === 0 ? "bg-purple-600/30 text-white" : "text-zinc-400 hover:bg-white/5"
                }`}
              >
                {item}
              </div>
            ))}
          </nav>

          <div className="mt-16 rounded-2xl border border-purple-500/30 bg-purple-950/20 p-5">
            <p className="font-bold">Season One Live</p>
            <p className="mt-1 text-sm text-zinc-400">May 2025 – Aug 2025</p>
            <div className="mt-4 h-2 rounded-full bg-zinc-800">
              <div className="h-2 w-2/3 rounded-full bg-purple-500" />
            </div>
          </div>
        </aside>

        <section className="flex-1">
          <header className="flex items-center justify-between border-b border-white/10 p-6">
            <input
              placeholder="Search players, teams, matches..."
              className="w-full max-w-xl rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none placeholder:text-zinc-500"
            />
            <div className="ml-6 hidden items-center gap-3 md:flex">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-purple-700 font-black">
                E
              </div>
              <div>
                <p className="font-bold">EAS Admin</p>
                <p className="text-xs text-zinc-400">Administrator</p>
              </div>
            </div>
          </header>

          <div className="p-6 lg:p-10">
            <section className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-r from-black via-[#090816] to-purple-950/40 p-8">
              <div className="relative z-10 max-w-2xl">
                <h2 className="text-4xl font-black md:text-5xl">
                  Climb the ranks. Own the arena.
                </h2>
                <p className="mt-4 text-zinc-300">
                  A competitive dashboard for EAS ranked players, placements,
                  MVPs, CR profiles, and staff tools.
                </p>

                <div className="mt-7 flex gap-3">
                  <a href="/leaderboard" className="rounded-xl bg-purple-600 px-5 py-3 font-bold hover:bg-purple-500">
                  View Leaderboard
                  </a>
                  <button className="rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-bold hover:bg-white/10">
                    Learn Ranks
                  </button>
                </div>
              </div>

              <div className="absolute right-10 top-8 hidden text-[150px] opacity-20 lg:block">
                🏆
              </div>
            </section>

            <section className="mt-6 grid gap-4 md:grid-cols-4">
              {[
                ["Total Players", "1,248", "+24 this week"],
                ["Matches Played", "3,842", "+156 this week"],
                ["MVPs Awarded", "312", "+12 this week"],
                ["Average CR", "2,134", "+38 this week"],
              ].map((stat) => (
                <div key={stat[0]} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                  <p className="text-sm text-zinc-400">{stat[0]}</p>
                  <p className="mt-2 text-3xl font-black">{stat[1]}</p>
                  <p className="mt-1 text-sm text-green-400">{stat[2]}</p>
                </div>
              ))}
            </section>

            <section className="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
              <div className="rounded-2xl border border-white/10 bg-white/[0.03]">
                <div className="flex items-center justify-between border-b border-white/10 p-6">
                  <div>
                    <h3 className="text-2xl font-black">🏆 Top Players</h3>
                    <p className="mt-1 text-sm text-zinc-400">
                      Pulled from PostgreSQL when connected
                    </p>
                  </div>
                  <span className="text-sm font-bold text-green-400">● LIVE</span>
                </div>

                <div className="divide-y divide-white/10">
                  {players.map((player) => (
                    <div key={player.name} className="grid grid-cols-[70px_1fr_100px_100px] items-center p-5">
                      <div className="text-xl">{player.place}</div>
                      <div className="flex items-center gap-3">
                        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-purple-900 font-black">
                          {player.letter}
                        </div>
                        <p className="font-bold">{player.name}</p>
                      </div>
                      <span className="w-fit rounded-lg border border-purple-500 px-3 py-1 text-purple-400">
                        {player.rank}
                      </span>
                      <p className="text-right text-xl font-black text-purple-400">
                        {player.cr}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-6">
                <div className="rounded-2xl border border-purple-500/30 bg-purple-950/20 p-6">
                  <h3 className="text-xl font-black">Season One Live</h3>
                  <p className="mt-2 text-sm text-zinc-400">May 2025 – Aug 2025</p>
                  <span className="mt-4 inline-block rounded-lg bg-green-500/20 px-3 py-1 text-sm font-bold text-green-400">
                    LIVE
                  </span>
                  <p className="mt-4 text-zinc-300">Compete, climb, and become a legend.</p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6">
                  <h3 className="text-xl font-black">⚡ Recent Activity</h3>
                  <div className="mt-5 space-y-4">
                    {players.map((player, i) => (
                      <div key={player.name} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-900 font-bold">
                            {player.letter}
                          </div>
                          <div>
                            <p className="font-bold">{player.name}</p>
                            <p className="text-xs text-zinc-400">Reached Rank {player.rank}</p>
                          </div>
                        </div>
                        <p className="text-xs text-zinc-500">{i * 10 + 2}m ago</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>
          </div>
        </section>
      </div>
    </main>
  );
}