import { query } from "@/lib/db";

async function getDiscordUser(userId: string) {
  try {
    if (!process.env.DISCORD_BOT_TOKEN) return null;

    const res = await fetch(`https://discord.com/api/v10/users/${userId}`, {
      headers: {
        Authorization: `Bot ${process.env.DISCORD_BOT_TOKEN}`,
      },
      cache: "no-store",
    });

    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

function getAvatar(user: any, userId: string) {
  if (!user?.avatar) {
    return `https://cdn.discordapp.com/embed/avatars/${Number(userId) % 5}.png`;
  }

  return `https://cdn.discordapp.com/avatars/${userId}/${user.avatar}.png?size=128`;
}

function getName(user: any, userId: string) {
  return user?.global_name || user?.username || `User ${userId}`;
}

export default async function Leaderboard() {
  let players: any[] = [];

  try {
    players = await query(`
      SELECT 
        user_id,
        data->>'cr' AS cr,
        data->>'wins' AS wins,
        data->>'losses' AS losses,
        data->>'kills' AS kills,
        data->>'mvp_count' AS mvp_count,
        data->>'win_streak' AS win_streak,
        data->>'placement_matches' AS placement_matches,
        data->>'ranked' AS ranked
      FROM players
      WHERE data->>'registered' = 'true'
      ORDER BY COALESCE((data->>'cr')::int, 0) DESC
      LIMIT 100
    `);
  } catch (err) {
    console.log("DB ERROR:", err);
  }

  const playersWithDiscord = await Promise.all(
    players.map(async (player) => {
      const discordUser = await getDiscordUser(player.user_id);
      return { ...player, discordUser };
    })
  );

  return (
    <main className="min-h-screen bg-[#05070d] text-white p-6 lg:p-10">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <a href="/" className="text-sm text-purple-400 hover:text-purple-300">
            ← Back to Dashboard
          </a>
          <h1 className="mt-3 text-4xl font-black">🏆 Leaderboard</h1>
          <p className="mt-2 text-zinc-400">
            Top registered EAS players sorted by CR.
          </p>
        </div>

        <div className="hidden rounded-2xl border border-purple-500/30 bg-purple-950/20 px-5 py-3 text-right md:block">
          <p className="text-sm text-zinc-400">Players Loaded</p>
          <p className="text-2xl font-black text-purple-400">
            {playersWithDiscord.length}
          </p>
        </div>
      </div>

      <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03]">
        <div className="grid grid-cols-[80px_1fr_120px_120px] border-b border-white/10 px-6 py-4 text-xs font-bold uppercase tracking-wider text-zinc-500">
          <span>Rank</span>
          <span>Player</span>
          <span className="text-center">Stats</span>
          <span className="text-right">CR</span>
        </div>

        {playersWithDiscord.length === 0 ? (
          <div className="p-10 text-center text-zinc-400">
            No players found or database is not connected.
          </div>
        ) : (
          playersWithDiscord.map((player, i) => {
            const name = getName(player.discordUser, player.user_id);
            const avatar = getAvatar(player.discordUser, player.user_id);

            return (
              <a
                href={`/player/${player.user_id}`}
                key={player.user_id}
                className="grid grid-cols-[80px_1fr_120px_120px] items-center border-b border-white/10 px-6 py-5 transition hover:bg-purple-500/10"
              >
                <div className="text-xl font-black">
                  {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i + 1}`}
                </div>

                <div className="flex items-center gap-4">
                  <img
                    src={avatar}
                    alt={name}
                    className="h-14 w-14 rounded-full border border-purple-500/50 object-cover"
                  />

                  <div>
                    <p className="text-lg font-black">{name}</p>
                    <p className="text-sm text-zinc-400">
                      Wins: {player.wins || 0} • Losses: {player.losses || 0} • Kills:{" "}
                      {player.kills || 0}
                    </p>
                    {!player.discordUser && (
                      <p className="mt-1 text-xs text-yellow-400">
                        Discord name unavailable
                      </p>
                    )}
                  </div>
                </div>

                <div className="text-center text-sm text-zinc-400">
                  <p>MVPs: {player.mvp_count || 0}</p>
                  <p>Streak: {player.win_streak || 0}</p>
                </div>

                <div className="text-right">
                  <p className="text-2xl font-black text-purple-400">
                    {player.cr || 0} CR
                  </p>
                  <p className="text-xs text-zinc-500">
                    Placements: {player.placement_matches || 0}
                  </p>
                </div>
              </a>
            );
          })
        )}
      </div>
    </main>
  );
}