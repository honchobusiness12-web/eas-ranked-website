import Link from "next/link";

export function Button({ children, href, variant = "solid", className = "" }: any) {
  const base = "inline-flex items-center justify-center rounded-2xl px-5 py-3 font-bold transition";
  const styles = variant === "outline"
    ? "border border-zinc-700 text-white hover:bg-zinc-900"
    : "bg-lime-400 text-black hover:bg-lime-300";
  if (href) return <Link href={href} className={`${base} ${styles} ${className}`}>{children}</Link>;
  return <button className={`${base} ${styles} ${className}`}>{children}</button>;
}

export function Card({ children, className = "" }: any) {
  return <div className={`rounded-3xl border border-zinc-800 bg-zinc-900/70 ${className}`}>{children}</div>;
}

export function PageShell({ children }: any) {
  return (
    <main className="min-h-screen bg-zinc-950 text-white">
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_top_left,rgba(132,204,22,0.18),transparent_35%),radial-gradient(circle_at_bottom_right,rgba(59,130,246,0.14),transparent_30%)]" />
      <div className="relative z-10 mx-auto max-w-7xl px-6 py-6">
        <nav className="mb-10 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-lime-400 font-black text-black">E</div>
            <div>
              <p className="font-black">EAS ARENA</p>
              <p className="text-xs text-zinc-400">Ranked Dashboard</p>
            </div>
          </Link>
          <div className="hidden gap-6 text-sm text-zinc-300 md:flex">
            <Link href="/leaderboard" className="hover:text-lime-300">Leaderboard</Link>
            <Link href="/placements" className="hover:text-lime-300">Placements</Link>
            <Link href="/ranks" className="hover:text-lime-300">Ranks</Link>
            <Link href="/admin" className="hover:text-lime-300">Admin</Link>
          </div>
        </nav>
        {children}
      </div>
    </main>
  );
}
