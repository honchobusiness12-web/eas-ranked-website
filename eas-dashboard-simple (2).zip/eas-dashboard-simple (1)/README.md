# EAS Dashboard Simple

This is the simple version: one Next.js app connects to your existing PostgreSQL database.

## 1. Install

```bash
npm install
```

## 2. Create `.env.local`

Copy `.env.example` and rename it to `.env.local`.

```env
DATABASE_URL=postgresql://USER:PASSWORD@HOST:PORT/DATABASE_NAME
DISCORD_CLIENT_ID=your_discord_client_id
DISCORD_CLIENT_SECRET=your_discord_client_secret
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=make_a_long_random_secret_here
DISCORD_GUILD_ID=your_server_id
STAFF_ROLE_IDS=role_id_1,role_id_2
DEVELOPER_USER_IDS=733871667788644445
```

## 3. Connect your current bot database

Open:

```txt
lib/schema.ts
```

This is where you match the website to your existing database.

Example:

```ts
export const TABLES = {
  players: "players",
  matches: "matches",
  placements: "placements",
};
```

If your bot table is called `player_stats`, change it:

```ts
players: "player_stats"
```

If your CR column is called `current_cr`, change:

```ts
cr: "current_cr"
```

## 4. Discord OAuth setup

Go to Discord Developer Portal → Your App → OAuth2 → Redirects.

Add this while testing locally:

```txt
http://localhost:3000/api/auth/callback/discord
```

Scopes used:

```txt
identify guilds guilds.members.read
```

## 5. Run the site

```bash
npm run dev
```

Open:

```txt
http://localhost:3000
```

## 6. Pages

```txt
/               Home
/leaderboard    Leaderboard
/player/ID      Player profile
/placements     Placement logs
/ranks          Rank system
/admin          Staff/admin tools
```

## 7. Important files

```txt
lib/db.ts        PostgreSQL connection
lib/schema.ts    Database table/column mapping
lib/auth.ts      Discord OAuth + staff check
lib/ranks.ts     Rank display system
app/admin        Admin page
app/api/admin    Admin actions
```

## 8. No data resets

This project does not drop tables, reset players, or delete data.
It only reads and updates rows through the pages/API routes.

## 9. If the site shows no data

Check these first:

1. DATABASE_URL is correct.
2. Your PostgreSQL allows outside connections.
3. `lib/schema.ts` table names match your real table names.
4. `lib/schema.ts` column names match your real column names.

