import NextAuth from "next-auth";
import Discord from "next-auth/providers/discord";

async function userIsStaff(accessToken: string, userId: string) {
  if (process.env.DEVELOPER_USER_IDS?.split(",").includes(userId)) return true;

  const guildId = process.env.DISCORD_GUILD_ID;
  const staffRoles = process.env.STAFF_ROLE_IDS?.split(",").filter(Boolean) || [];
  if (!guildId || staffRoles.length === 0) return false;

  const res = await fetch(`https://discord.com/api/users/@me/guilds/${guildId}/member`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) return false;
  const member = await res.json();
  return member.roles?.some((roleId: string) => staffRoles.includes(roleId));
}

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    Discord({
      clientId: process.env.DISCORD_CLIENT_ID!,
      clientSecret: process.env.DISCORD_CLIENT_SECRET!,
      authorization: "https://discord.com/api/oauth2/authorize?scope=identify+guilds+guilds.members.read",
    }),
  ],
  callbacks: {
    async jwt({ token, account, profile }) {
      if (account?.access_token) token.accessToken = account.access_token;
      if (profile?.id) token.discordId = profile.id;
      if (account?.access_token && profile?.id) {
        token.isStaff = await userIsStaff(account.access_token, profile.id);
      }
      return token;
    },
    async session({ session, token }) {
      (session as any).accessToken = token.accessToken;
      (session as any).discordId = token.discordId;
      (session as any).isStaff = token.isStaff;
      return session;
    },
  },
});
