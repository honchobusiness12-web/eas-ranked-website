export const ranks = [
  { rank: "R1", name: "Rookie", cr: "0 - 249 CR" },
  { rank: "R2", name: "Amateur", cr: "250 - 499 CR" },
  { rank: "R3", name: "Pro", cr: "500 - 799 CR" },
  { rank: "R4", name: "Elite", cr: "800 - 1,099 CR" },
  { rank: "R5", name: "All-Star", cr: "1,100 - 1,449 CR" },
  { rank: "R6", name: "Superstar", cr: "1,450 - 1,799 CR" },
  { rank: "R7", name: "Remorseless", cr: "1,800 - 2,099 CR" },
  { rank: "R8", name: "Legend", cr: "2,100 - 2,399 CR" },
  { rank: "R9", name: "Unreal", cr: "2,400 - 2,699 CR" },
  { rank: "R10", name: "Hall Of Fame", cr: "2,700+ CR" },
];
