import { Pool } from "pg";

if (!process.env.DATABASE_URL) {
  throw new Error("Missing DATABASE_URL in .env.local");
}

export const db = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL.includes("localhost")
    ? false
    : { rejectUnauthorized: false },
});

export async function query<T = any>(sql: string, params: any[] = []): Promise<T[]> {
  const result = await db.query(sql, params);
  return result.rows;
}
