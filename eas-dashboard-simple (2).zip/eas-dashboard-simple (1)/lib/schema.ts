// CHANGE THESE NAMES TO MATCH YOUR REAL POSTGRESQL TABLES/COLUMNS.
// This file is the main connection map between your old bot database and the website.

export const TABLES = {
  players: "players",
  matches: "matches",
  placements: "placements",
};

export const PLAYER_COLUMNS = {
  discordId: "discord_id",
  username: "username",
  cr: "cr",
  rank: "rank",
  wins: "wins",
  losses: "losses",
  mvps: "mvps",
  winStreak: "win_streak",
  suspended: "suspended",
  blacklisted: "blacklisted",
  updatedAt: "updated_at",
};
